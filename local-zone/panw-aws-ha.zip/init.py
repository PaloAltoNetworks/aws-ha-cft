import time
import json
import logging
import http.client
import decimal
import uuid
import hashlib
import base64
import urllib.request, urllib.parse, urllib.error
import urllib.request, urllib.error, urllib.parse
import ssl
import os
import boto3
import traceback
import subprocess
from http.client import HTTPSConnection
from urllib.parse import urlparse
from contextlib import closing
import xml.etree.ElementTree as et
import sys
sys.path.append('lib/')
import awshalib as lib
import traceback

events_client = boto3.client('events')
ec2_client = boto3.client('ec2')
lambda_client = boto3.client('lambda')
iam = boto3.client('iam')

def cidr_to_netmask(cidr):
  cidr = int(cidr)
  mask = (0xffffffff >> (32 - cidr)) << (32 - cidr)
  return (str( (0xff000000 & mask) >> 24)   + '.' +
          str( (0x00ff0000 & mask) >> 16)   + '.' +
          str( (0x0000ff00 & mask) >> 8)    + '.' +
          str( (0x000000ff & mask)))

def get_netmask_from_subnet_prefix(vpc_id, subnet_id):
    #print ec2_client
    #print ec2_client.describe_instances(InstanceIds=['i-03edaab7e980c76e6'])
    response = ec2_client.describe_subnets(
        Filters=[
            {
                'Name': 'vpc-id',
                'Values': [
                    vpc_id,
                ],
            },
        ],
        SubnetIds=[subnet_id]
    )
    #print response
    netmask = None
    if response.get('ResponseMetadata').get('HTTPStatusCode') == 200:
        subnet_info = response.get('Subnets')[0]
        cidr = subnet_info.get('CidrBlock')
        prefix = cidr.split('/')[1]
        netmask = cidr_to_netmask(prefix)
        #print netmask
    return netmask

def send_response(event, context, responseStatus):
    """
    Method to send a response back to the CFT process.

    :param event:
    :param context:
    :param responseStatus:
    :return:
    """
    r=responseStatus.split(":")
    print(r)
    rs=str(r[0])
    reason=""
    if len(r) > 1:
        reason = str(r[1])
    else:
        reason = 'See the details in CloudWatch Log Stream.'
    print("Event in send_response: %s" % event)
    print('send_response() to stack -- responseStatus: ' + str(rs) + ' Reason: ' + str(reason))
    try:
        response = {
                'Status': str(rs),
                'Reason': str(reason),
                'StackId': event['StackId'],
                'RequestId': event['RequestId'],
                'LogicalResourceId': event['LogicalResourceId'],
                'PhysicalResourceId': event['LogicalResourceId']
                   }
    except Exception as e:
        print("Exception. Error:%s Traceback:%s" % (str(e), traceback.format_exc()))
        response = {
                'Status': str(rs),
                'Reason': str(reason)
                   }
    print('RESPONSE: ' + json.dumps(response))
    parsed_url = urlparse(event['ResponseURL'])
    if (parsed_url.hostname == ''):
        print('[ERROR]: Parsed URL is invalid...')
        return 'false'

    print('[INFO]: Sending Response...')
    try:
        with closing(http.client.HTTPSConnection(parsed_url.hostname)) as connection:
            connection.request("PUT", parsed_url.path+"?"+parsed_url.query, json.dumps(response))
            response = connection.getresponse()
            if response.status != 200:
                print('[ERROR]: Received non 200 response when sending response to cloudformation')
                print('[RESPONSE]: ' + response.msg)
                return 'false'
            else:
                print('[INFO]: Got good response')

    except:
        print('[ERROR]: Got ERROR in sending response...')
        return 'false'
    finally:

        connection.close()
        return 'true'

def lambda_handler(event, context):
    # TODO implement
    try:
        #TODO: Based on CREATE or DELETE create fw_init lambda
        #TODO: Delete lambda subnets interfaces when the stack is deleted. Otherwise, stack deletion would fail.
        print("Printing Event")
        print(event)
        print("Printing r")
        r = event.get('ResourceProperties')
        print(r)

        lambda_exec_role_name=r['LambdaExecutionRole']
        print("lambda_exec_role_name: %s" % lambda_exec_role_name)
        lambda_exec_role_arn = iam.get_role(RoleName=lambda_exec_role_name).get('Role').get('Arn')
        print("lambda_exec_role_arn: %s" % lambda_exec_role_arn)
        SubnetIDsLambda=r['SubnetIDsLambda']
        SubnetIDsLambda=(lib.fix_unicode(SubnetIDsLambda)).decode('utf-8')
        subnetids = SubnetIDsLambda.split(",")
        print("subnetids: %s" % subnetids)
        SecurityGroupId = r['PANSecurityGroup']
        print("SecurityGroupIds: %s" % SecurityGroupId)
        FWKey = r['KeyPANWFirewall']
        print("FWKey: %s" % FWKey)
        LambdaS3Bucket = r['LambdaS3Bucket']
        print("LambdaS3Bucket: %s" % LambdaS3Bucket)
        StackName = r['StackName']
        print("StackName: %s" % StackName)
        MgmtSubnetId = r['MgmtSubnetId']
        HA2SubnetId = r['HA2SubnetId']
        FW1MgmtIP = r['FW1MgmtIP']
        FW2MgmtIP = r['FW2MgmtIP']
        FW1HA2IP = r['FW1HA2IP']
        FW2HA2IP = r['FW2HA2IP']
        VPCId = r['VPCId']
        #subnet_id = 'subnet-0fb1dc919fb961f4a'
        #vpc_id = 'vpc-0e4b457cb6a66e9ae'
        MgmtNetmask = get_netmask_from_subnet_prefix(VPCId, MgmtSubnetId)
        HA2Netmask = get_netmask_from_subnet_prefix(VPCId, HA2SubnetId)
        print("Mgmt Netmask:%s" % MgmtNetmask)
        print("HA2 Netmask:%s" % HA2Netmask)
        print("FW1MgmtIP: %s" % FW1MgmtIP)
        print("FW2MgmtIP: %s" % FW2MgmtIP)
        print("FW1HA2IP: %s" % FW1HA2IP)
        print("FW2HA2IP: %s" % FW2HA2IP)
        print("VPCId: %s" % VPCId)

        #try:
            #response=ec2_client.describe_network_interfaces(Filters=[{'Name': "group-id", 'Values': [str(SecurityGroupId)]}])
            #print response
        #except Exception as e:
            #print "Error getting lambda interfaces. Error:%s" % str(e)

        if event['RequestType'] == 'Create':
            print("Request type is create. Creating fw_init lambda")
            response = events_client.put_rule(
                    Name='%s_lambda_rule' % StackName,
                    ScheduleExpression='rate(1 minute)',
                    State='ENABLED'
                )
            events_source_arn = response.get('RuleArn')
            print("events_source_arn: %s" % events_source_arn)

            response = lambda_client.create_function(
                    FunctionName='%s_lambda_fw_init' % StackName,
                    Runtime='python3.7',
                    Role=lambda_exec_role_arn,
                    Handler='fw_init.lambda_handler',
                    Code={
                        'S3Bucket': LambdaS3Bucket,
                        'S3Key': 'panw-aws-ha.zip'
                    },
                    MemorySize=256,
                    Timeout=900,
                    VpcConfig={
                        'SubnetIds': subnetids,
                        'SecurityGroupIds': [
                            SecurityGroupId
                        ]
                    }
                )
            fw_init_lambda_arn = response.get('FunctionArn')
            print("fw_init_lambda_arn: %s" % fw_init_lambda_arn)

            response = lambda_client.add_permission(
                    FunctionName=fw_init_lambda_arn,
                    StatementId= '%s_fw_init_statement_id' % StackName,
                    Action='lambda:InvokeFunction',
                    Principal='events.amazonaws.com',
                    SourceArn=events_source_arn
                )

            Input = {
                "FWKey" : FWKey,
                "subnetids" : subnetids,
                "FW1MgmtIP" : FW1MgmtIP,
                "FW2MgmtIP" : FW2MgmtIP,
                "FW1HA2IP" : FW1HA2IP,
                "FW2HA2IP" : FW2HA2IP,
                "MgmtNetmask" : MgmtNetmask,
                "HA2Netmask" : HA2Netmask,
                "VPCId" : VPCId,
                "StackName" : StackName
            }
            response= events_client.put_targets(
                    Rule='%s_lambda_rule' % StackName,
                    Targets=
                        [{
                            'Id': '%s_lambda_target_id' % StackName,
                            'Arn': fw_init_lambda_arn,
                            'Input': json.dumps(Input)
                        }]
                )
        if event['RequestType'] == 'Delete':
            print("Request type is delete. Deleting Lambda subnet associated enis")
            try:
                print('Delete ENI for Lambda with VPC SG if any...')
                lib.delete_eni_lambda(SecurityGroupId)
            except Exception as e:
                 print("[delete ENI lambda]: {}".format(e))
    except Exception as e:
        print("Exception occurred. Error: %s" % str(e))

    status = "SUCCESS"
    if (send_response(event, context, status)) == 'false':
        print("Failed to send response")

