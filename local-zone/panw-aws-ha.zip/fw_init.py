import time
import json
import logging
import http.client
import decimal
import uuid
import hashlib
import base64
import urllib.request, urllib.parse, urllib.error
import urllib.request, urllib.error, urllib.parse
import ssl
import os
import boto3
import botocore
import traceback
import subprocess
from http.client import HTTPSConnection
from urllib.parse import urlparse
from contextlib import closing
import xml.etree.ElementTree as et
import sys
sys.path.append('lib/')
import awshalib as lib
import pan_xml as pxl
import traceback

ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client
lambda_client = boto3.client('lambda')
iam = boto3.client('iam')
events_client = boto3.client('events')

"""
Response:
null

Request ID:
"7552c9aa-d54a-4f97-9be7-d2573bf682b3"

Function logs:
: 10.4.1.12
FW1HA2IP: 10.4.2.11
FW2HA2IP: 10.4.2.12
https://10.4.1.11/api/?type=config&key=LUFRPT1hbHQ1c2dPNDN4MTNwV1J6T0tMbkxUVG85VkU9NU9yalI4MmRvVGdWOWw1N2x1bk0vZ0VSS08vSjFYOTVvOUkxajlLcEhKQXBuVkdtdkFhcEN0cFptTVZlNTkwWA==&action=set&xpath=/config/devices/entry[@name='localhost.localdomain']/network/interface/ethernet/entry[@name='ethernet1/1']&element=<ha/>
response: <response status="success" code="20"><msg>command succeeded</msg></response>
set fw ha config
<response status="success" code="20"><msg>command succeeded</msg></response>
https://10.4.1.11/api/?type=config&key=LUFRPT1hbHQ1c2dPNDN4MTNwV1J6T0tMbkxUVG85VkU9NU9yalI4MmRvVGdWOWw1N2x1bk0vZ0VSS08vSjFYOTVvOUkxajlLcEhKQXBuVkdtdkFhcEN0cFptTVZlNTkwWA==&action=set&xpath=/config/devices/entry[@name='localhost.localdomain']/deviceconfig&element=<high-availability><group><group-id>10</group-id><state-synchronization><ha2-keep-alive><enabled>yes</enabled></ha2-keep-alive></state-synchronization><election-option><device-priority>10</device-priority><timers><recommended/></timers></election-option><peer-ip>10.4.1.12</peer-ip></group><enabled>yes</enabled><interface><ha2><port>ethernet1/1</port><ip-address>10.4.2.11</ip-address><netmask>255.255.255.0</netmask></ha2><ha1><port>management</port></ha1></interface></high-availability>
response: <response status="success" code="20"><msg>command succeeded</msg></response>
set fw ha config
<response status="success" code="20"><msg>command succeeded</msg></response>
https://10.4.1.11/api/?type=commit&cmd=<commit></commit>&key=LUFRPT1hbHQ1c2dPNDN4MTNwV1J6T0tMbkxUVG85VkU9NU9yalI4MmRvVGdWOWw1N2x1bk0vZ0VSS08vSjFYOTVvOUkxajlLcEhKQXBuVkdtdkFhcEN0cFptTVZlNTkwWA==
response: <response status="success" code="19"><result><msg><line>Commit job enqueued with jobid 7</line></msg><job>7</job></result></response>
commit done
<response status="success" code="19"><result><msg><line>Commit job enqueued with jobid 7</line></msg><job>7</job></result></response>
https://10.4.1.12/api/?type=config&key=LUFRPT1hbHQ1c2dPNDN4MTNwV1J6T0tMbkxUVG85VkU9NU9yalI4MmRvVGdWOWw1N2x1bk0vZ0VSS08vSjFYOTVvOUkxajlLcEhKQXBuVkdtdkFhcEN0cFptTVZlNTkwWA==&action=set&xpath=/config/devices/entry[@name='localhost.localdomain']/network/interface/ethernet/entry[@name='ethernet1/1']&element=<ha/>
response: <response status="success" code="20"><msg>command succeeded</msg></response>
set fw ha config
<response status="success" code="20"><msg>command succeeded</msg></response>
https://10.4.1.12/api/?type=config&key=LUFRPT1hbHQ1c2dPNDN4MTNwV1J6T0tMbkxUVG85VkU9NU9yalI4MmRvVGdWOWw1N2x1bk0vZ0VSS08vSjFYOTVvOUkxajlLcEhKQXBuVkdtdkFhcEN0cFptTVZlNTkwWA==&action=set&xpath=/config/devices/entry[@name='localhost.localdomain']/deviceconfig&element=<high-availability><group><group-id>10</group-id><state-synchronization><ha2-keep-alive><enabled>yes</enabled></ha2-keep-alive></state-synchronization><election-option><device-priority>10</device-priority><timers><recommended/></timers></election-option><peer-ip>10.4.1.11</peer-ip></group><enabled>yes</enabled><interface><ha2><port>ethernet1/1</port><ip-address>10.4.2.12</ip-address><netmask>255.255.255.0</netmask></ha2><ha1><port>management</port></ha1></interface></high-availability>
response: <response status="success" code="20"><msg>command succeeded</msg></response>
set fw ha config
<response status="success" code="20"><msg>command succeeded</msg></response>
https://10.4.1.12/api/?type=commit&cmd=<commit></commit>&key=LUFRPT1hbHQ1c2dPNDN4MTNwV1J6T0tMbkxUVG85VkU9NU9yalI4MmRvVGdWOWw1N2x1bk0vZ0VSS08vSjFYOTVvOUkxajlLcEhKQXBuVkdtdkFhcEN0cFptTVZlNTkwWA==
response: <response status="success" code="19"><result><msg><line>Commit job enqueued with jobid 5</line></msg><job>5</job></result></response>
commit done
<response status="success" code="19"><result><msg><line>Commit job enqueued with jobid 5</line></msg><job>5</job></result></response>
END RequestId: 7552c9aa-d54a-4f97-9be7-d2573bf682b3
REPORT RequestId: 7552c9aa-d54a-4f97-9be7-d2573bf682b3  Duration: 2789.16 ms    Billed Duration: 2800 ms    Memory Size: 256 MB Max Memory Used: 131 MB Init Duration: 1011.53 ms

"""

def remove_fw_init_lambda(stack_name):
    event_rule_name = '%s_lambda_rule' % stack_name
    target_id_name = '%s_lambda_target_id' % stack_name
    lambda_func_name = '%s_lambda_fw_init' % stack_name
    try:
        events_client.remove_targets(Rule=event_rule_name,
                    Ids=[target_id_name])
    except Exception as e:
        print("[Remove Targets]: {}".format(e))

    print('Deleting event rule: ' +  event_rule_name)
    try:
        events_client.delete_rule(Name=event_rule_name)
    except Exception as e:
        print("[Delete Rule]: {}".format(e))

    print('Delete lambda function: ' + lambda_func_name)
    try:
        lambda_client.delete_function(FunctionName=lambda_func_name)
        return True
    except Exception as e:
        print("[Delete Lambda Function]: {}".format(e))

def pan_response(response):
    ret = 'FAIL'
    try:
        resp_xml = pxl.str_to_xml(response)
        status = pxl.xml_get_prop(resp_xml, 'status')
        if status == 'success':
            ret = 'OK'
    except Exception as e:
        print("Failed parsing pan response. Error:%s" % str(e))

    return ret

def pan_commit(gcontext, MgmtIp, fwApiKey):
    fw_cmd='https://'+MgmtIp+"/api/?type=commit&cmd=<commit></commit>&key="+fwApiKey
    print(fw_cmd)
    response = None
    try:
        response = lib.runCommand(gcontext, fw_cmd, MgmtIp, fwApiKey)
        if response is None:
            #pan_print('CFG_FW_GET_SERIAL_NO: Failed to run command: ' + fw_cmd)
            print('Failed to run command: ' + fw_cmd)
            return 'FAIL'
        else:
            print("response: %s" % response)
    except Exception as e:
        #pan_print("[CFG_FW_GET_SERIAL_NO]: {}".format(e))
        print('Failed to run command: ' + fw_cmd)
        return 'FAIL'

    print("commit done")
    return pan_response(response)

def set_ha_intf_config(gcontext, MgmtIp, fwApiKey):
    #cmd = "/config/devices/entry[@name='localhost.localdomain']/deviceconfig/system"
    cmd = "/config/devices/entry[@name='localhost.localdomain']/network/interface/ethernet/entry[@name='ethernet1/1']"
    #element = '<ethernet><entry name=\"ethernet1/1\"><layer3/></entry></ethernet>'
    element = '<ha/>'

    fw_cmd='https://'+MgmtIp+'/api/?type=config&key='+fwApiKey+'&action=set&xpath='+ cmd+'&element=%s' % element
    print(fw_cmd)
    response = None
    try:
        response = lib.runCommand(gcontext, fw_cmd, MgmtIp, fwApiKey)
        if response is None:
            #pan_print('CFG_FW_GET_SERIAL_NO: Failed to run command: ' + fw_cmd)
            print('Failed to run command: ' + fw_cmd)
            return 'FAIL'
        else:
            print("response: %s" % response)
    except Exception as e:
        #pan_print("[CFG_FW_GET_SERIAL_NO]: {}".format(e))
        print('Failed to run command: ' + fw_cmd)
        return 'FAIL'

    print("Firewall HA interface config set.")
    return pan_response(response)

def set_ha_config(gcontext, MgmtIp, fwApiKey, peerIp, ha2Ip, ha2Netmask, FW1=True):
    #cmd = "/config/devices/entry[@name='localhost.localdomain']/deviceconfig/system"
    priority = 10
    if FW1 == False:
        priority = 20
    cmd = "/config/devices/entry[@name='localhost.localdomain']/deviceconfig"
    """
        <high-availability>
          <group>
            <group-id>10</group-id>
            <state-synchronization>
              <ha2-keep-alive>
                <enabled>yes</enabled>
              </ha2-keep-alive>
            </state-synchronization>
            <election-option>
              <device-priority>10</device-priority>
              <timers>
                <recommended/>
              </timers>
            </election-option>
            <peer-ip>10.4.1.11</peer-ip>
          </group>
          <enabled>yes</enabled>
          <interface>
            <ha2>
              <port>ethernet1/1</port>
              <ip-address>10.4.2.11</ip-address>
              <netmask>255.255.255.0</netmask>
            </ha2>
            <ha1>
              <port>management</port>
            </ha1>
          </interface>
        </high-availability>
    """
    element = '<high-availability><group><group-id>10</group-id><state-synchronization><ha2-keep-alive>' \
              '<enabled>yes</enabled></ha2-keep-alive></state-synchronization><election-option><device-priority>%d</device-priority>' \
              '<timers><recommended/></timers></election-option><peer-ip>%s</peer-ip></group><enabled>yes</enabled>' \
              '<interface><ha2><port>ethernet1/1</port><ip-address>%s</ip-address><netmask>%s</netmask></ha2>'\
              '<ha1><port>management</port></ha1></interface></high-availability>' % (priority, peerIp, ha2Ip, ha2Netmask)

    fw_cmd='https://'+MgmtIp+'/api/?type=config&key='+fwApiKey+'&action=set&xpath='+ cmd+'&element=%s' % element
    print(fw_cmd)
    response = None
    try:
        response = lib.runCommand(gcontext, fw_cmd, MgmtIp, fwApiKey)
        if response is None:
            #pan_print('CFG_FW_GET_SERIAL_NO: Failed to run command: ' + fw_cmd)
            print('Failed to run command: ' + fw_cmd)
            return 'FAIL'
        else:
            print("response: %s" % response)
    except Exception as e:
        #pan_print("[CFG_FW_GET_SERIAL_NO]: {}".format(e))
        print('Failed to run command: ' + fw_cmd)
        return 'FAIL'

    print("Firewall HA config set.")
    return pan_response(response)

def lambda_handler(event, context):
    # TODO implement
    print("Printing Event")
    print(event)
    FWKey = event['FWKey']
    FW1MgmtIP = event['FW1MgmtIP']
    FW2MgmtIP = event['FW2MgmtIP']
    FW1HA2IP = event['FW1HA2IP']
    FW2HA2IP = event['FW2HA2IP']
    VPCId = event['VPCId']
    MgmtNetmask = event['MgmtNetmask']
    HA2Netmask = event['HA2Netmask']
    StackName = event['StackName']
    #subnet_id = 'subnet-0fb1dc919fb961f4a'
    #vpc_id = 'vpc-0e4b457cb6a66e9ae'
    #MgmtNetmask = get_netmask_from_subnet_prefix(VPCId, MgmtSubnetId)
    #HA2Netmask = get_netmask_from_subnet_prefix(VPCId, HA2SubnetId)
    print("FWKey: %s" % FWKey)
    print("Mgmt Netmask:%s" % MgmtNetmask)
    print("HA2 Netmask:%s" % HA2Netmask)
    print("FW1MgmtIP: %s" % FW1MgmtIP)
    print("FW2MgmtIP: %s" % FW2MgmtIP)
    print("FW1HA2IP: %s" % FW1HA2IP)
    print("FW2HA2IP: %s" % FW2HA2IP)
    print("VPCId: %s" % VPCId)
    print("StackName: %s" % StackName)

    ctx = lib.get_ssl_context()
    try:
        #Check if firewall is ready before configuring HA.
        FW1_Ready = False
        FW2_Ready = False
        if lib.is_firewall_ready(ctx, FW1MgmtIP, FWKey) == False:
            print("Firewall1 is not in ready state")
        else:
            print("Firewall1 is in ready state")
            FW1_Ready = True
        if lib.is_firewall_ready(ctx, FW2MgmtIP, FWKey) == False:
            print("Firewall2 is not in ready state")
        else:
            print("Firewall2 is in ready state")
            FW2_Ready = True

        if not FW1_Ready and not FW2_Ready:
            print("Firewalls are not in ready state")
            return
        else:
            print("Firewalls are in ready state for HA configuration")

        FW1_HA_CONFIG_STATE = 'OK'
        FW2_HA_CONFIG_STATE = 'OK'
        if set_ha_intf_config(ctx, FW1MgmtIP, FWKey) == 'FAIL':
            FW1_HA_CONFIG_STATE = 'FAIL'
        if set_ha_config(ctx, FW1MgmtIP, FWKey, FW2MgmtIP, FW1HA2IP, HA2Netmask) == 'FAIL':
            FW1_HA_CONFIG_STATE = 'FAIL'
        if FW1_HA_CONFIG_STATE == 'OK':
            if pan_commit(ctx, FW1MgmtIP, FWKey) == 'FAIL':
                FW1_HA_CONFIG_STATE = 'FAIL'
            else:
                print("FW1_HA_CONFIG_STATE is OK")

        if set_ha_intf_config(ctx, FW2MgmtIP, FWKey) == 'FAIL':
            FW2_HA_CONFIG_STATE = 'FAIL'
        if set_ha_config(ctx, FW2MgmtIP, FWKey, FW1MgmtIP, FW2HA2IP, HA2Netmask, FW1=False) == 'FAIL':
            FW2_HA_CONFIG_STATE = 'FAIL'
        if FW2_HA_CONFIG_STATE == 'OK':
            if pan_commit(ctx, FW2MgmtIP, FWKey) == 'FAIL':
                FW2_HA_CONFIG_STATE = 'FAIL'
            else:
                print("FW2_HA_CONFIG_STATE is OK")

        if FW1_HA_CONFIG_STATE == 'OK' and FW2_HA_CONFIG_STATE == 'OK':
            print("Firewall HA configuration is successfull. Deleting Lambda")
            remove_fw_init_lambda(StackName)
    except Exception as e:
        print("Failed to set ha config. Error:%s Traceback:%s" % (str(e), traceback.format_exc()))
    #return {
        #'statusCode': 200,
        #'body': json.dumps('Hello from Lambda!')
    #}

