"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from __future__ import print_function

import boto3
import botocore
import json
import logging
import time
import socket
import struct
import decimal
import uuid
import logging
import urllib2
import urllib
import ssl
import xml.etree.ElementTree as et
from httplib import HTTPSConnection
import re
import os
import traceback
import xmltodict
from boto3.dynamodb.conditions import Key, Attr


logger = logging.getLogger()

# Enable creation of S3 bucket per-ASG
enable_s3=False

######## BOTO3 Clients and Resources #############
s3 = boto3.client('s3')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client
lambda_client = boto3.client('lambda')
iam = boto3.client('iam')
events_client = boto3.client('events')
cloudwatch = boto3.client('cloudwatch')

def substring_after(s, delim):
    """

    :param s:
    :param delim:
    :return:
    """
    return s.partition(delim)[2]

def fix_unicode(data):
    """
        Method to convert opaque data from unicode to utf-8
        :param data: Opaque data
        :return: utf-8 encoded data
    """
    if isinstance(data, unicode):
        return data.encode('utf-8')
    elif isinstance(data, dict):
        data = dict((fix_unicode(k), fix_unicode(data[k])) for k in data)
    elif isinstance(data, list):
        for i in xrange(0, len(data)):
            data[i] = fix_unicode(data[i])

    return data

def fix_subnets(data1):
    """

    :param data1:
    :return:
    """
    data=str(data1)
    data=data.replace("'", "")
    data=data.replace("[", "")
    data=data.replace("]", "")
    return data

def ip2int(addr):
    """

    :param addr:
    :return:
    """
    return struct.unpack("!I", socket.inet_aton(addr))[0]

def int2ip(addr):
    """

    :param addr:
    :return:
    """
    return socket.inet_ntoa(struct.pack("!I", addr))

def get_subnet_and_gw(ip_cidr):
    """
    Extract subnet and gateway from subnet cidr in AWS

    :param ip_cidr:
    :return:
    """
    addr_mask = ip_cidr.split('/')
    addr = addr_mask[0]
    try:
        mask = addr_mask[1]
    except IndexError:
        mask = '32'

    # convert to int
    addr = ip2int(addr)
    mask = int(mask)

    subnet = addr & ((0xFFFFFFFF << (32 - mask)) & 0xFFFFFFFF)
    if mask == 32:
        gw = addr
    else:
        gw = subnet | 1

    return (int2ip(subnet), int2ip(gw))

def execute_command( url, ret_dict=True):
    ctx = get_default_ssl_context()
    print('Executed URL %s' % url)
    try:
        req = urllib2.Request(url)
        response = urllib2.urlopen(req, context=ctx)
        xml_resp = response.read()

            # If you want to return the response as xml.

        if not ret_dict:
            return (True, ET.fromstring(xml_resp))

        o = xmltodict.parse(xml_resp, force_list=['entry'])
    except Exception, e:
        print('Execution of cmd failed with %s' % str(e))
        return (False, str(e))

    if o['response']['@status'].lower() == 'success':
        if 'type=op' in url or 'action=get' \
            in url:
            return (True, o['response']['result'])
        return (True, o['response'])
    else:
        return (False, o['response'])

def runCommand(gcontext, cmd, gwMgmtIp, api_key):
    """

    Method to run generic API commands against a PAN Firewall.

    .. note:: This is a generic method to interact with PAN
              firewalls to execute api calls.

    :param gcontext: SSL Context
    :param cmd: Command to execute
    :param gwMgmtIp: Management IP of the PAN FW
    :param api_key: API key of the Firewall
    :return: None or str
    """
    try:
        response = urllib2.urlopen(cmd, context=gcontext, timeout=5).read()
        logger.info("[RESPONSE] in send command: {}".format(response))
    except Exception as e:
        logger.error("[RunCommand Response Fail]: {}".format(e))
        return None

    resp_header = et.fromstring(response)

    if resp_header.tag != 'response':
        logger.error("[ERROR]: didn't get a valid response from Firewall command: " + cmd)
        return None

    if resp_header.attrib['status'] == 'error':
        logger.error("[ERROR]: Got an error for the command: " + cmd)
        return None

    if resp_header.attrib['status'] == 'success':
        return response

    return None

def get_ssl_context():
    """
    Create default ssl context
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.options = ssl.PROTOCOL_TLSv1_2
    return ctx

def deactivate_fw_license_panorama(panorama_ip,panorama_key,serial_no):
    url = "https://" + panorama_ip + "/api/?type=op&key=" + panorama_key
    url += "&cmd=<request><batch><license><deactivate><VM-Capacity>"
    url += "<mode>auto</mode>"
    url += "<devices>" + serial_no + "</devices>"
    url += "</VM-Capacity></deactivate></license></batch></request>"
    ok, result = execute_command(url)
    if not ok:
        logger.error('Deactivation of VM with serial %s failed' % serial_no)
        return False, result
    return True, result

def deactivate_fw_license(gcontext, instanceId, gwMgmtIp, fwApiKey):
    """
    Call the FW to deactivate the license from the licensing
    server

    :param gcontext: ssl context
    :param instanceId: instance Id
    :param gwMgmtIP: The IP address of the FW
    :param fwApiKey: Api key of the FW

    :return: Api call status
    :rtype: bool
    """

    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return False

    logger.info('Deactivate and the license for FW: {} with IP: {}'.format(instanceId, gwMgmtIp))

    fw_cmd = "https://{}/api/?type=op&key={}&cmd=<request><license><deactivate><VM-Capacity><mode>auto</mode></VM-Capacity></deactivate></license></request>".format(gwMgmtIp, fwApiKey)
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response is None:
            pan_print('CFG_FW_DELICENSE: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
        pan_print("[CFG_FW_DELICENSE]: {}".format(e))
        return False

    return True

def shutdown_fw_device(gcontext, instanceId, gwMgmtIp, fwApiKey):
    """
    Shutdown the firewall device

    :param gcontext: ssl context
    :param instanceId: instance Id
    :param gwMgmtIP: The IP address of the FW
    :param fwApiKey: Api key of the FW

    :return: Api call status
    :rtype: bool
    """
    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return False

    logger.info('Shutdown the firewall device : {} with IP: {}'.format(instanceId, gwMgmtIp))

    fw_cmd = "https://{}/api/?type=op&key={}&cmd=<request><shutdown><system></system></shutdown></request>".format(gwMgmtIp, fwApiKey)

    try:
        response = runShutdownCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response == False:
            pan_print('CFG_FW_SHUTDOWN: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
        pan_print("[CFG_FW_SHUTDOWN]: {}".format(e))
        return False

    return True

def set_deactivate_api_key(gcontext, instanceId, gwMgmtIp, fwApiKey, deactivateApiKey):
    """
    Setup the deactivate api key to allow the FW deactivate sequence
    :param instanceId:
    :param gwMgmtIp:
    :param fwApiKey:
    :param deactivateApiKey:
    :return: bool
    """

    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return False

    logger.info('Setup the deactivate API Key on the FW for device {} with IP: {}'.format(instanceId, gwMgmtIp))

    fw_cmd = "https://{}/api/?type=op&key={}&cmd=<request><license><api-key><set><key>{}</key></set></api-key></license></request>".format(gwMgmtIp, fwApiKey, deactivateApiKey)
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response is None:
            pan_print('CFG_FW_SET_DELIC_KEY: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
        pan_print("[CFG_FW_SET_DELIC_KEY]: {}".format(e))
        return False

    return True

# Lambda ENIs when deployed in NAT Gateway mode don't go away (because of VPCconfig)
#
def delete_eni_lambda(vpc_sg):
    """

    :param vpc_sg:
    :return:
    """
    print('Look for ENIs in Lambda VPC SG: ' + vpc_sg)
    response=ec2_client.describe_network_interfaces(Filters=[{'Name': "group-id", 'Values': [str(vpc_sg)]}])
    print(response)
    good=True
    for i in response['NetworkInterfaces']:
        eniId=i['NetworkInterfaceId']
        if i['Status'] == "available":
            try:
                ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
            except Exception as e:
                logger.warning("[Lambda delete Eni]: {}".format(e))
                good=False
            continue

        Attachment=i['Attachment']
        aId=Attachment['AttachmentId']
        print('Detaching Eni ID: ' + eniId + ' Desc: ' + i['Description'] + ' IP: ' + i['PrivateIpAddress'] + ' AZ: ' + i['AvailabilityZone'])
        print('Detaching Attachment ID: ' + aId + ' DeviceIndex: ' +  str(Attachment['DeviceIndex']))
        if Attachment['DeviceIndex'] != 0:
            try:
                ec2_client.modify_network_interface_attribute(NetworkInterfaceId=eniId,
                           Attachment={ 'AttachmentId': aId, 'DeleteOnTermination': True})
                ec2_client.detach_network_interface(AttachmentId=aId, Force=True)
                ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
            except Exception as e:
                good=False
                logger.warning("[Lambda detach Eni]: {}".format(e))
                try:
                    ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
                except Exception as e:
                    logger.warning("[Lambda delete Eni in modify/delete]: {}".format(e))

    return good

remote = 0
def pan_print(s):
    """

    :param s:
    :return:
    """
    if remote > 0:
        logger.info(s)
        return
    print(s)
    return

def getChassisReady(response):
    """

    :param response:
    :return:
    """
    s1=response.replace('\n',"")
    s1=s1.replace(" ","")
    if s1.find("<![CDATA[no]]") > 0:
        return False
    if s1.find("<![CDATA[yes]]>") > 0:
        return True
    return False

def is_firewall_ready(gcontext, gwMgmtIp, api_key):
    """

    :param gcontext:
    :param gwMgmtIp:
    :param api_key:
    :return:
    """
    pan_print('Checking whether Chassis is ready or not')
    cmd="<show><chassis-ready/></show>"
    fw_cmd= "https://"+gwMgmtIp+"/api/?type=op&cmd=" + cmd + "&key="+api_key
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, api_key)
        if response is None:
            pan_print('Failed to run command: ' + fw_cmd)
            return False
        status=getChassisReady(response)
        if status == True:
            pan_print('Chassis is in ready state')
            return True
        else:
            pan_print('Chassis is not ready yet')

        pan_print("[RESPONSE] in send command: {}".format(response))
    except Exception as e:
         logger.error("[AutoCommit RESPONSE]: {}".format(e))

    return False

def get_default_ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx
