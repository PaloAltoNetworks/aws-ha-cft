import xml.etree.cElementTree as ET
from xml.etree.cElementTree import ElementTree, Element, SubElement, dump, tostring, fromstring
import re


def str_to_xml(tmp_str):
    try:
        return fromstring(tmp_str)
    except:
        return None

def xml_to_file(root, filename, pretty_print=False):
    try:
        if not pretty_print:
            tree = ET.ElementTree(root)
            tree.write(filename)
        else:
            from xml.dom import minidom
            tmp_str = minidom.parseString(
                tostring(root)).toprettyxml(indent="")
            #tmp_str = minidom.parseString(tostring(root)).toprettyxml()
            fo = open(filename, "rw+")
            fo.write(tmp_str)
            fo.close()
    except:
        return -1
    return 0

def xml_get_node_name(root):
    return root.tag

def xml_get_children(root):
    return root.getchildren()


def xml_to_str(_root, pretty_print=False):
    try:
        if not pretty_print:
            return tostring(_root)
        else:
            from xml.dom import minidom
            return minidom.parseString(tostring(_root)).toprettyxml(indent="\t")
    except:
        return None


def xml_nodes_to_str(_root):
    mstr = ""
    try:
        for _child in _root:
            mstr += (tostring(_child))
        return mstr
    except:
        return None


def xml_get_prop(_root, _name):
    try:
        if _name == None:
            return _root.attrib.items()
        return _root.attrib[_name]
    except:
        return None


def xml_node_get_content(root):
    try:
        tmp_str = (root.text)
        if tmp_str != None and len(tmp_str.strip()) > 0:
            return tmp_str
        else:
            return None
    except:
        return None


def xml_get_node_by_xpath(_root, _xpath):
    try:
        return _root.find(_xpath)
    except:
        return None

def xml_get_node_by_xpath_inlist(_root, _xpath_inlist):
    if _root == None or _xpath_inlist == None:
        return None

    for _xpath in _xpath_inlist:
        try:
            tmp_val = xml_get_node_by_xpath(_root, _xpath)
            if tmp_val == None:
                continue
            return tmp_val
        except:
            continue
    return None


def xml_get_nodeset_by_xpath(_root, _xpath):
    if _root == None or _xpath == None:
        return None
    try:
        return _root.findall(_xpath)
    except:
        return None


def xml_get_node_by_xpath_value(root, xpath):
    node = xml_get_node_by_xpath(root, xpath)
    return xml_node_get_content(node)


def xml_get_node_by_xpath_value_dict(_root, my_list, replace_list=[]):
    ret_dict = {}
    
    if not replace_list:
        replace_list = my_list

    for idx, ml in enumerate(my_list):
        tmp_val = xml_get_node_by_xpath_value(_root, ml)
        ret_dict[ replace_list[idx] ] = tmp_val
    return ret_dict

def xml_get_node_by_xpath_value_inlist(root, xpath_list):
    node = xml_get_node_by_xpath_inlist(root, xpath_list)
    return xml_node_get_content(node)

def xml_get_parent_node(_root):
    return xml_get_node_by_xpath(_root, "..")

def file_to_xml(file_name):
    try:
        return ET.parse(file_name).getroot()
    except:
        return None


def xml_remove_node(doc, node):
    doc.remove(node)


def xml_node_add_content(node, text):
    node.text = text


def xml_add_child(root, node):
    root.append(node)


def xml_new_node(node_name, text=None):
    tmp_node = Element(node_name)
    if text != None:
        xml_node_add_content(tmp_node, text)
    return tmp_node

def xml_add_new_node(root, node_name, node_value=None):
    new_node = xml_new_node(node_name, node_value)
    xml_add_child(root, new_node)


def xml_get_prop(root, attr_name=None):
    if attr_name != None:
        
        if attr_name not in root.attrib:
            return None

        return root.attrib[attr_name]
    else:
        return root.attrib


def xml_set_prop(root, att, att_val):
    if root == None or att == None or att_val == None:
        return -1
    try:
        root.set(att, att_val)
    except:
        return -1

    return 0
